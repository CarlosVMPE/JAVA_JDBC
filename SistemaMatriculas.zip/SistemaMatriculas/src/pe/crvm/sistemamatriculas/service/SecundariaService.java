
package pe.crvm.sistemamatriculas.service;

import java.util.List;
import pe.crvm.sistemamatriculas.dao.espec.DaoSecundariaEspec;
import pe.crvm.sistemamatriculas.dao.imple.DaoSecundariaImple;
import pe.crvm.sistemamatriculas.domain.Secundaria;
import pe.crvm.sistemamatriculas.util.Dialogo;

public class SecundariaService {
    
    private DaoSecundariaEspec dao;
    
    public SecundariaService(){
        dao = new DaoSecundariaImple();
    }
    
    public List<Secundaria> getClientes(Secundaria bean){
        return dao.readForCriteria(bean);
    } 
    
    public void insert(Secundaria bean){
        dao.insert(bean);
    }
    
    public void update(Secundaria bean) {
     dao.update(bean);
      Dialogo.info(null, "Alumno actualizado correctamente!");
  }

  public void delete(Secundaria bean) {
    dao.delete(bean.getCodigo());
      Dialogo.info(null, "Alumno eliminado correctamente!");
  }
}
