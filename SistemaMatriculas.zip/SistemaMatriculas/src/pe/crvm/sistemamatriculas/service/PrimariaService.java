
package pe.crvm.sistemamatriculas.service;

import java.util.List;
import pe.crvm.sistemamatriculas.dao.espec.DaoPrimariaEspec;
import pe.crvm.sistemamatriculas.dao.imple.DaoPrimariaImple;
import pe.crvm.sistemamatriculas.domain.Primaria;
import pe.crvm.sistemamatriculas.util.Dialogo;

public class PrimariaService {
    
    private DaoPrimariaEspec dao;
    
    public PrimariaService(){
        dao = new DaoPrimariaImple();
    }
    
    public List<Primaria> getClientes(Primaria bean){
        return dao.readForCriteria(bean);
    } 
    
    public void insert(Primaria bean){
        dao.insert(bean);
    }
    
    public void update(Primaria bean) {
     dao.update(bean);
      Dialogo.info(null, "Alumno actualizado correctamente!");
  }

  public void delete(Primaria bean) {
    dao.delete(bean.getCodigo());
      Dialogo.info(null, "Alumno eliminado correctamente!");
  }
}
