
package pe.crvm.sistemamatriculas.service;

import pe.crvm.sistemamatriculas.dao.espec.DaoAdministradorEspec;
import pe.crvm.sistemamatriculas.dao.imple.DaoAdministradorImple;
import pe.crvm.sistemamatriculas.domain.Administrador;

/**
 *
 * @author Carlos
 */
public class LogonService {
     public Administrador validar(String usuario, String clave){
        Administrador bean = null;
        DaoAdministradorEspec dao = new DaoAdministradorImple();
        bean = dao.validar(usuario, clave);
        return bean;    
    }
}
