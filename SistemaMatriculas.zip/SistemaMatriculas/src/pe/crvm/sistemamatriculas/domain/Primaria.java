
package pe.crvm.sistemamatriculas.domain;

import java.util.Date;
import pe.crvm.sistemamatriculas.util.Convertidor;

/**
 *
 * @author Carlos
 */
public class Primaria {
    private String codigo;
    private String paterno;
    private String materno;
    private String nombre;
    private String dni;
    private String fechaMat;
    private String direccion;
    private String telefono;
    private String grado;
    private String seccion;

    public Primaria() {
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getPaterno() {
        return paterno;
    }

    public void setPaterno(String paterno) {
        this.paterno = paterno;
    }

    public String getMaterno() {
        return materno;
    }

    public void setMaterno(String materno) {
        this.materno = materno;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getFechaMat() {
        return fechaMat;
    }

    public void setFechaMat(String fechaMat) {
        this.fechaMat = fechaMat;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }

    public String getSeccion() {
        return seccion;
    }

    public void setSeccion(String seccion) {
        this.seccion = seccion;
    }
    
    
    
}
