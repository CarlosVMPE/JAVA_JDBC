
package pe.crvm.sistemamatriculas.controller;

import java.util.List;
import pe.crvm.sistemamatriculas.domain.Primaria;
import pe.crvm.sistemamatriculas.service.PrimariaService;
import pe.crvm.sistemamatriculas.util.Matricula;


public class PrimariaController {
    private final PrimariaService service;
    public PrimariaController(){
        service = new PrimariaService();
    }
    
    public List<Primaria> getClientes(Primaria bean){
        return service.getClientes(bean);
    }

    public void grabar(Primaria bean, String accion) {
        switch(accion){
            case Matricula.CRUD_NUEVO:
                service.insert(bean);
                break;
                
            case Matricula.CRUD_EDITAR:
                service.update(bean);
                break;
        
            case Matricula.CRUD_ELIMINAR:
                service.delete(bean);
                break;
        }
    }
    
    
}
