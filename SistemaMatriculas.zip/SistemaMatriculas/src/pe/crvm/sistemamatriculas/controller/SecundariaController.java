
package pe.crvm.sistemamatriculas.controller;

import java.util.List;
import pe.crvm.sistemamatriculas.domain.Secundaria;
import pe.crvm.sistemamatriculas.service.SecundariaService;
import pe.crvm.sistemamatriculas.util.Matricula;


public class SecundariaController {
    private final SecundariaService service;
    public SecundariaController(){
        service = new SecundariaService();
    }
    
    public List<Secundaria> getClientes(Secundaria bean){
        return service.getClientes(bean);
    }

    public void grabar(Secundaria bean, String accion) {
        switch(accion){
            case Matricula.CRUD_NUEVO:
                service.insert(bean);
                break;
                
            case Matricula.CRUD_EDITAR:
                service.update(bean);
                break;
        
            case Matricula.CRUD_ELIMINAR:
                service.delete(bean);
                break;
        }
    }
    
    
}
