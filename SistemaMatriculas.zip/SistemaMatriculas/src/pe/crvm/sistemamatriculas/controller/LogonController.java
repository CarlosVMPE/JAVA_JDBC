package pe.crvm.sistemamatriculas.controller;


import pe.crvm.sistemamatriculas.domain.Administrador;
import pe.crvm.sistemamatriculas.service.LogonService;
import pe.crvm.sistemamatriculas.util.Memoria;

/**
 *
 * @author Gustavo Coronel
 */
public class LogonController {
  
  public void validar(String usuario, String clave){
    LogonService service = new LogonService();
    Administrador admin = service.validar(usuario, clave);
    if(admin == null){
      throw new RuntimeException("Usuario o clave incorrecto.");
    } else {
      Memoria.put("usuario", admin);
    }
  }
}
