
package pe.crvm.sistemamatriculas.dao.espec;

import pe.crvm.sistemamatriculas.domain.Administrador;

/**
 *
 * @author Carlos
 */
public interface DaoAdministradorEspec extends DaoCrudEspec<Administrador>{
    
    Administrador validar(String usuario, String clave);
}
