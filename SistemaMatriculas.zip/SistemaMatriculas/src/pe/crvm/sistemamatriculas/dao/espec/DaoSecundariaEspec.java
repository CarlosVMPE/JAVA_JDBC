/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.crvm.sistemamatriculas.dao.espec;

import pe.crvm.sistemamatriculas.domain.Secundaria;

/**
 *
 * @author LAB-USR-AQ265-A0905
 */
public interface DaoSecundariaEspec extends DaoCrudEspec<Secundaria>{
    
}
