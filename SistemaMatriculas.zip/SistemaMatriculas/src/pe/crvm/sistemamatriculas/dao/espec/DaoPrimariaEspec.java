
package pe.crvm.sistemamatriculas.dao.espec;

import pe.crvm.sistemamatriculas.domain.Primaria;


public interface DaoPrimariaEspec extends DaoCrudEspec<Primaria>{
    
}
