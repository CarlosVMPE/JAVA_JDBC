/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.crvm.sistemamatriculas.dao.imple;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import pe.crvm.sistemamatriculas.dao.espec.DaoAdministradorEspec;
import pe.crvm.sistemamatriculas.db.AccesoDB;
import pe.crvm.sistemamatriculas.domain.Administrador;

/**
 *
 * @author Carlos
 */
public class DaoAdministradorImple implements DaoAdministradorEspec{

    @Override
    public Administrador validar(String usuario, String clave) {
         Administrador admin = null;
         Connection cn = null;
    try {
      cn = AccesoDB.getConnection();
     /* String sql = "select chr_emplcodigo, vch_emplpaterno, "
              + "vch_emplmaterno, vch_emplnombre, vch_emplciudad, "
              + "vch_empldireccion, vch_emplusuario "
              + "from empleado "
              + "where vch_emplusuario = ? "
              + "and vch_emplclave = ? ";*/
      String sql = "select CHR_ADMCODIGO, " 
                    +"VCH_ADMPATERNO, VCH_ADMMATERNO, " 
                    +"VCH_ADMNOMBRE, VCH_ADMCIUDAD, " 
                    +"VCH_ADMDIRECCION, VCH_ADMUSUARIO, " 
                    +"VCH_ADMCLAVE "
                    +"from ADMINISTRADOR "
                    +"where VCH_ADMUSUARIO = ? "
                    +"and VCH_ADMCLAVE = ? ";
      PreparedStatement pstm = cn.prepareStatement(sql);
      pstm.setString(1, usuario);
      pstm.setString(2, clave);
      ResultSet rs = pstm.executeQuery();
      if(rs.next()){
        admin = getBean(rs);
      }
      rs.close();
      pstm.close();
    } catch (SQLException e) {
      throw new RuntimeException(e.getMessage());
    } catch (Exception e) {
      String mensaje = "Se ha producido un error, intentelo mas tarde.";
      if (e.getMessage() != null && !e.getMessage().isEmpty()) {
        mensaje += (" " + e.getMessage());
      }
      throw new RuntimeException(mensaje);
    } finally {
      try {
        cn.close();
      } catch (Exception e) {
      }
    }
    
    return admin;
    }

    @Override
    public Administrador readForId(String codigo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Administrador> readAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Administrador> readForCriteria(Administrador bean) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void insert(Administrador bean) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(Administrador bean) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(String codigo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    //////////////////////////
    
    private Administrador getBean(ResultSet rs) throws SQLException{
    Administrador bean = new Administrador();
    bean.setCodigo(rs.getString("CHR_ADMCODIGO"));
    bean.setPaterno(rs.getString("VCH_ADMPATERNO"));
    bean.setMaterno(rs.getString("VCH_ADMMATERNO"));
    bean.setNombre(rs.getString("VCH_ADMNOMBRE"));
    bean.setCiudad(rs.getString("VCH_ADMCIUDAD"));
    bean.setDireccion(rs.getString("VCH_ADMDIRECCION"));
    bean.setUsuario(rs.getString("VCH_ADMUSUARIO"));
    return bean;
  }
    
}
