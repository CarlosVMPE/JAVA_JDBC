
package pe.crvm.sistemamatriculas.dao.imple;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import pe.crvm.sistemamatriculas.dao.espec.DaoPrimariaEspec;
import pe.crvm.sistemamatriculas.db.AccesoDB;
import pe.crvm.sistemamatriculas.domain.Primaria;



public class DaoPrimariaImple implements DaoPrimariaEspec{

    @Override
    public Primaria readForId(String codigo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Primaria> readAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Primaria> readForCriteria(Primaria bean) {
        List<Primaria> lista = new ArrayList<>();
        Connection cn = null;
        try {
            cn = AccesoDB.getConnection();
           
            String sql = "select chr_pricodigo, vch_pripaterno, "
                         + "vch_primaterno, vch_prinombre, "
                         + "chr_pridni, vch_prifechamat, "
                         + "vch_pridireccion, vch_pritelefono, chr_prigrado, "
                         + "chr_priseccion "
                         + "from primaria "
                         + "where vch_pripaterno like ? "
                         + "and vch_primaterno like ? "
                         + "and vch_prinombre like ?";
            
            PreparedStatement pstm = cn.prepareStatement(sql);
            pstm.setString(1, bean.getPaterno() +"%");
            pstm.setString(2, bean.getMaterno()+"%");
            pstm.setString(3, bean.getNombre()+"%");
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                Primaria primaria = getBean(rs);
                lista.add(primaria);
            }
            
            rs.close();
            pstm.close();
            
        } catch (SQLException e) {
            throw new RuntimeException(e.getMessage());
        } catch(Exception e){
            String mensaje = " Se ha producito un error, intentelo mas tarde.";
            if (e.getMessage() != null && !e.getMessage().isEmpty()) {
            mensaje += (" " + e.getMessage());
            }
            throw new RuntimeException(mensaje);
        } finally{
            try {
                cn.close();
            } catch (Exception e) {
              }
          }
        
        return lista;
    }

    @Override
    public void insert(Primaria bean) {
        Connection cn = null;
        try{
            //Acceso al objecto Connection
            cn = AccesoDB.getConnection();
            //Inicia Tx
            cn.setAutoCommit(false);
            // Incrementar el contador
            String sql = "update contador " +
                        "set int_contitem  = int_contitem + 1 " +
                        "where vch_conttabla  = 'Primaria' ";
            PreparedStatement pstm = cn.prepareStatement(sql);
            int filas = pstm.executeUpdate();
            pstm.close();
            if (filas == 0){
                throw new Exception("Contador no existe.");
            }
            
            // Leer contador
            sql =   "select int_contitem, int_contlongitud "
                    + "from contador "
                    + "where vch_conttabla = 'Primaria' ";
            pstm = cn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            rs.next();
            int cont = rs.getInt("int_contitem");
            int size = rs.getInt("int_contlongitud");
            
            // Crear Codigo
            
            String formato = "%1$0" + size + "d";
            String codigo = String.format(formato,cont);
            
            // Insertar Cliente
            sql = "insert into primaria(chr_pricodigo, vch_pripaterno, "
              + "vch_primaterno, vch_prinombre, "
              + "chr_pridni, vch_prifechamat, "
              + "vch_pridireccion, vch_pritelefono, chr_prigrado, "
              + "chr_priseccion) "
              + "values(?,?,?,?,?,?,?,?,?,?)";
            
            pstm = cn.prepareStatement(sql);
            pstm.setString(1,  codigo);
            pstm.setString(2,  bean.getPaterno());
            pstm.setString(3,  bean.getMaterno());
            pstm.setString(4,  bean.getNombre());
            pstm.setString(5,  bean.getDni());
            pstm.setString(6,  bean.getFechaMat());
            pstm.setString(7,  bean.getDireccion());
            pstm.setString(8,  bean.getTelefono());
            pstm.setString(9,  bean.getGrado());
            pstm.setString(10, bean.getSeccion());
            pstm.executeUpdate();
            pstm.close();
            
            bean.setCodigo(codigo);
            ////////////////////////////////
            
            //Confirma Tx
            cn.commit();
            
        }catch(Exception e){
            try{
                cn.rollback();
            }catch(Exception e1){
                
            }
            String mensaje = "Error en el Proceso.";
            if(e.getMessage() !=  null && !e.getMessage().isEmpty() ){
                mensaje += " " + e.getMessage();
            }
            throw new RuntimeException(mensaje);
        }finally{
            try {
                cn.close();
            } catch (Exception e) {
              }
          }
    }

    @Override
    public void update(Primaria bean) {
        Connection cn = null;
    try {
      cn = AccesoDB.getConnection();
      cn.setAutoCommit(false); // Inicia la Tx
      String sql = "update primaria set  vch_pripaterno = ?, "
              + "vch_primaterno = ?, vch_prinombre = ?, "
              + "chr_pridni = ?, vch_prifechamat = ?, "
              + "vch_pridireccion = ?, vch_pritelefono = ?, "
              + "chr_prigrado = ? , chr_priseccion = ? "
              + "where chr_pricodigo = ?";
      PreparedStatement pstm = cn.prepareStatement(sql);
      pstm.setString(1, bean.getPaterno());
      pstm.setString(2, bean.getMaterno());
      pstm.setString(3, bean.getNombre());
      pstm.setString(4, bean.getDni());
      pstm.setString(5, bean.getFechaMat());
      pstm.setString(6, bean.getDireccion());
      pstm.setString(7, bean.getTelefono());
      pstm.setString(8, bean.getGrado());
      pstm.setString(9, bean.getSeccion());
      pstm.setString(10, bean.getCodigo());
      pstm.executeUpdate();
      cn.commit();
    } catch (SQLException e) {
      try {
        cn.rollback();
      } catch (Exception e1) {
      }
      throw new RuntimeException(e.getMessage());
    } catch (Exception e) {
      try {
        cn.rollback();
      } catch (Exception e1) {
      }
      throw new RuntimeException("Error en el proceso.");
    } finally {
      try {
        cn.close();
      } catch (Exception e) {
      }
    }
    }

    @Override
    public void delete(String codigo) {
        Connection cn = null;
        try {
                cn = AccesoDB.getConnection();
                cn.setAutoCommit(false); // Inicia la Tx
                String sql = "DELETE FROM primaria WHERE chr_pricodigo= ?";
                PreparedStatement pstm = cn.prepareStatement(sql);
                pstm.setString(1, codigo);
                pstm.executeQuery();
      
                cn.commit();
        } catch (SQLException e) {
            try {
                    cn.rollback();
            } catch (Exception e1) {
              }
        throw new RuntimeException(e.getMessage());
        } catch (Exception e) {
            try {
            cn.rollback();
        } catch (Exception e1) {
        }
      throw new RuntimeException("Error en el proceso.");
        } finally {
            try {
                cn.close();
            } catch (Exception e) {
            }
        }
    }

    private Primaria getBean(ResultSet rs) throws SQLException {
    Primaria bean = new Primaria();
    bean.setCodigo(rs.getString("chr_pricodigo"));
    bean.setPaterno(rs.getString("vch_pripaterno"));
    bean.setMaterno(rs.getString("vch_primaterno"));
    bean.setNombre(rs.getString("vch_prinombre"));
    bean.setDni(rs.getString("chr_pridni"));
    bean.setFechaMat(rs.getString("vch_prifechamat"));
    bean.setDireccion(rs.getString("vch_pridireccion"));
    bean.setTelefono(rs.getString("vch_pritelefono"));
    bean.setGrado(rs.getString("chr_prigrado"));
    bean.setSeccion(rs.getString("chr_priseccion"));
    return bean;
  }
    
    
    
   
    
}
