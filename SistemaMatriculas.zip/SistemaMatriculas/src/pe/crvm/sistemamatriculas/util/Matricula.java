
package pe.crvm.sistemamatriculas.util;


public final class Matricula {

    public Matricula() {
    }
    
    // Constantes del CRUD
    public final static String CRUD_EDITAR = "EDITAR";
    public final static String CRUD_ELIMINAR = "ELIMINAR";
    public final static String CRUD_NUEVO = "NUEVO";
    
}
