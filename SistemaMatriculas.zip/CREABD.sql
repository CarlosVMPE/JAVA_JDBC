/*
Empresa        :  EurekaBank
Software       :  Sistema de Cuentas de Ahorro
DBMS           :  Oracle
Base de Datos  :  eurekabank
Script         :  Crea la Base de Datos
Responsable    :  Ing. Eric Gustavo Coronel Castillo
Telefono       :  (511) 9966-64457
Email          :  gcoronelc@gmail.com
Blog           :  http://gcoronelc.blogspot.com
*/

-- =============================================
-- CRACI�N DE LA APLICACI�N
-- =============================================

DECLARE
	N INT;
	COMMAND VARCHAR2(200);
BEGIN
	COMMAND := 'DROP USER prueba2 CASCADE';
	SELECT COUNT(*) INTO N
	FROM DBA_USERS
	WHERE USERNAME = 'PRUEBA2';
	IF ( N = 1 ) THEN
		EXECUTE IMMEDIATE COMMAND;
	END IF;
END;
/

-- Valido para la versi�n 12
ALTER SESSION SET "_ORACLE_SCRIPT"=TRUE;

CREATE USER prueba2 IDENTIFIED BY admin;

GRANT CONNECT, RESOURCE TO prueba2;

ALTER USER PRUEBA2
QUOTA UNLIMITED ON USERS;


-- =============================================
-- CONECTARSE A LA APLICACI�N
-- =============================================

CONNECT prueba2/admin


-- =============================================
-- CREACI�N DE LOS OBJETOS DE LA BASE DE DATOS
-- =============================================

CREATE TABLE Administrador (
       chr_admcodigo       CHAR(4) NOT NULL,
       vch_admpaterno      VARCHAR(25) NOT NULL,
       vch_admmaterno      VARCHAR(25) NOT NULL,
       vch_admnombre       VARCHAR(30) NOT NULL,
       vch_admciudad       VARCHAR(30) NOT NULL,
       vch_admdireccion    VARCHAR(50) NOT NULL,
       vch_admusuario      VARCHAR(15) NOT NULL,
       vch_admclave        VARCHAR(15) NOT NULL,
       CONSTRAINT XPKAdministrador
              PRIMARY KEY (chr_admcodigo)
);

CREATE TABLE Primaria (
       chr_pricodigo       CHAR(5) NOT NULL,
       vch_pripaterno      VARCHAR(25) NOT NULL,
       vch_primaterno      VARCHAR(25) NOT NULL,
       vch_prinombre       VARCHAR(30) NOT NULL,
       chr_pridni          CHAR(8) NOT NULL,
       vch_prifechamat     VARCHAR(30) NOT NULL,
       vch_pridireccion    VARCHAR(35) NOT NULL,
       vch_pritelefono     VARCHAR(15) NOT NULL,
       chr_prigrado        CHAR(3) NOT NULL,
       chr_priseccion      CHAR(1) NOT NULL,
       CONSTRAINT XPKPrimaria
              PRIMARY KEY (chr_pricodigo)
);

CREATE TABLE Secundaria (
       chr_seccodigo       CHAR(5) NOT NULL,
       vch_secpaterno      VARCHAR(25) NOT NULL,
       vch_secmaterno      VARCHAR(25) NOT NULL,
       vch_secnombre       VARCHAR(30) NOT NULL,
       chr_secdni          CHAR(8) NOT NULL,
       vch_secfechamat     VARCHAR(30) NOT NULL,
       vch_secdireccion    VARCHAR(30) NOT NULL,
       vch_sectelefono     VARCHAR(15) NOT NULL,
       chr_secgrado        CHAR(3) NOT NULL,
       chr_secseccion      CHAR(1) NOT NULL,
       CONSTRAINT XPKSecundaria
              PRIMARY KEY (chr_seccodigo)
);

CREATE TABLE Contador (
       vch_conttabla        VARCHAR(30) NOT NULL,
       int_contitem         NUMBER(6,0) NOT NULL,
       int_contlongitud     NUMBER(3,0) NOT NULL,
       CONSTRAINT XPKContador 
              PRIMARY KEY (vch_conttabla)
);

CREATE TABLE Cuenta (
       chr_admcodigo        CHAR(4) NOT NULL,
       chr_pricodigo        CHAR(5) NOT NULL,
       chr_seccodigo        CHAR(5) NOT NULL,

       CONSTRAINT fk_administrador 
              FOREIGN KEY (chr_admcodigo)
			     REFERENCES Administrador, 
       CONSTRAINT fk_primaria
              FOREIGN KEY (chr_pricodigo)
                             REFERENCES Primaria, 
       CONSTRAINT fk_secundaria
              FOREIGN KEY (chr_seccodigo)
                             REFERENCES Secundaria
);



