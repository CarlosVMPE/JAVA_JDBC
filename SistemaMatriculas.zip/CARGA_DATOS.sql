/*
Empresa        :  EurekaBank
Software       :  Sistema de Cuentas de Ahorro
DBMS           :  Orecle
Base de Datos  :  eurekabank
Script         :  Carga Datos
Responsable    :  Eric Gustavo Coronel Castillo
Telefono       :  (511) 9966-64457
Email          :  gcoronelc@gmail.com
Sitio          :  http://www.perudev.net
Blog           :  http://gcoronelc.blogspot.com
*/


-- =============================================
-- CARGAR DATOS DE PRUEBA
-- =============================================

-- Tabla: Administrador

INSERT INTO administrador VALUES( '0001', 'Vilchez', 'Malasquez', 'Carlos Raymundo', 'Lima', 'Los Chasquis 118', 'cvilchez', 'demon' );
INSERT INTO administrador VALUES( '0002', 'Castro', 'Vargas', 'Lidia', 'Lima', 'Federico Villarreal 456 - SMP', 'lcastro', 'suerte' );
INSERT INTO administrador VALUES( '0003', 'Reyes', 'Ortiz', 'Claudia', 'Lima', 'Av. Aviaci�n 3456 - San Borja', 'creyes', 'linda' );
INSERT INTO administrador VALUES( '0004', 'Ramos', 'Garibay', 'Angelica', 'Chiclayo', 'Calle Barcelona 345', 'aramos', 'china' );
INSERT INTO administrador VALUES( '0005', 'Ruiz', 'Zabaleta', 'Claudia', 'Cusco', 'Calle Cruz Verde 364', 'cvalencia', 'angel' );
INSERT INTO administrador VALUES( '0006', 'Cruz', 'Tarazona', 'Ricardo', 'Areguipa', 'Calle La Gruta 304', 'rcruz', 'cerebro' );
INSERT INTO administrador VALUES( '0007', 'Torres', 'Diaz', 'Guino', 'Lima', 'Av. Salaverry 1416', 'gtorres', 'talento' );


-- Tabla: Primaria

insert into primaria values( '00001', 'CORONEL', 'CASTILLO', 'ERIC GUSTAVO', '06914897', '2016/03/01', 'LOS OLIVOS','9666-4457', '1ro','A');
insert into primaria values( '00002', 'VALENCIA', 'MORALES', 'PEDRO HUGO', '01576173', '2016/03/01', 'MAGDALENA', '924-7834','1ro', 'A' );
insert into primaria values( '00003', 'MARCELO', 'VILLALOBOS', 'RICARDO', '10762367', '2016/03/02', 'LINCE', '993-62966', '2do', 'A' );
insert into primaria values( '00004', 'ROMERO', 'CASTILLO', 'CARLOS ALBERTO', '06531983', '2016/03/02', 'LOS OLIVOS', '865-84762', '2do' ,'B' );
insert into primaria values( '00005', 'ARANDA', 'LUNA', 'ALAN ALBERTO', '10875611', '2016/03/03', 'SAN ISIDRO', '834-67125', '2do', 'B' );
insert into primaria values( '00006', 'AYALA', 'PAZ', 'JORGE LUIS', '10679245', '2016/03/03', 'SAN BORJA', '963-34769', '3ro' ,'B' );
insert into primaria values( '00007', 'CHAVEZ', 'CANALES', 'EDGAR RAFAEL', '10145693', '2016/03/04', 'MIRAFLORES', '999-96673', '3ro', 'C' );
insert into primaria values( '00008', 'FLORES', 'CHAFLOQUE', 'ROSA LIZET', '10773456', '2016/03/04', 'LA MOLINA', '966-87567', '4to','C' );
insert into primaria values( '00009', 'FLORES', 'SHUTE', 'CRISTIAN RAFAEL', '10346723', '2016/03/05', 'LOS OLIVOS', '978-43768', '5to','B');
insert into primaria values( '00010', 'GONZALES', 'GARCIA', 'GABRIEL ALEJANDRO', '10192376', '2016/03/06', 'SAN MIGUEL', '945-56782', '6to', 'A' );

-- Tabla: Secundaria

insert into secundaria values( '00001', 'LAY', 'VALLEJOS', 'JUAN CARLOS', '10942287', '2016/03/01', 'LINCE', '956-12657', '1ro','B' );
insert into secundaria values( '00002', 'MONTALVO', 'SOTO', 'DEYSI LIDIA', '10612376', '2016/03/01', 'SURCO', '965-67235', '1ro','B' );
insert into secundaria values( '00003', 'RICALDE', 'RAMIREZ', 'ROSARIO ESMERALDA', '10761324', '2016/03/01', 'MIRAFLORES', '991-23546', '2do','A' );
insert into secundaria values( '00004', 'RODRIGUEZ', 'RAMOS', 'ENRIQUE MANUEL', '10773345', '2016/03/02', 'LINCE', '976-82838', '2do','A' );
insert into secundaria values( '00005', 'ROJAS', 'OSCANOA', 'FELIX NINO', '10238943', '2016/03/02','LIMA', '962-32158', '3ro' ,'C' );
insert into secundaria values( '00006', 'TEJADA', 'DEL AGUILA', 'TANIA LORENA', '10446791', '2016/03/02', 'PUEBLO LIBRE', '966-23854', '3ro' ,'C' );
insert into secundaria values( '00007', 'VALDEVIESO', 'LEYVA', 'ROXANA', '10452682', '2016/03/03', 'LOS OLIVOS', '956-78951', '3ro' ,'B' );
insert into secundaria values( '00008', 'VALENTIN', 'COTRINA', 'JUAN DIEGO', '10398247', '2016/03/05', 'LA MOLINA', '921-12456', '4to','A' );
insert into secundaria values( '00009', 'YAURICASA', 'BAUTISTA', 'YESABETH', '10934584', '2016/03/05', 'MAGDALENA', '977-75777', '5to','B' );
insert into secundaria values( '00010', 'ZEGARRA', 'GARCIA', 'FERNANDO MOISES', '10772365', '2016/03/05', 'SAN ISIDRO', '936-45876', '5to','B' );



--  Tabla: Contador

insert into Contador Values( 'Administrador', 6, 4 );
insert into Contador Values( 'Primaria', 11, 5 );
insert into Contador Values( 'Secundaria', 11, 5 );


-- Actualizar Contadores

update contador
set int_contitem = (select count(*) from administrador)
where vch_conttabla = 'Administrador';

update contador
set int_contitem = (select count(*) from primaria)
where vch_conttabla = 'Primaria';

update contador
set int_contitem = (select count(*) from secundaria)
where vch_conttabla = 'Secundaria';

commit;
